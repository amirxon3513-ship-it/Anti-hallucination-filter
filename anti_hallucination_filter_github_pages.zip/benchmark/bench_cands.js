// Vector prefilter -> K-engine over the candidates only. Accuracy and engine time.
const fs = require('fs'); const CL = require('./engine.js'); const loadPresets = require('./presets.js'); const { decide } = require('./pipeline.js');
const Q = require('./queries.json'); const D = JSON.parse(fs.readFileSync('distractors.json', 'utf8')); const C = JSON.parse(fs.readFileSync('candidates.json', 'utf8'));
const med = a => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * p))]; };
function build(kind, M) {
  const e = new CL.Engine(); loadPresets(e); e.log.length = 0;
  const nNear = kind === 'mix' ? Math.floor(M * 0.2) : 0, nRand = M - nNear;
  for (const d of D.rand.slice(0, nRand).concat(D.near.slice(0, nNear))) e.reg.set(d.id, { id: d.id, text: d.text, K: d.K, t: 0, refs: [], history: [{ t: 0, K: d.K }], forced: null, sources: [] });
  return e;
}
const out = []; const byCfg = {};
for (const key of Object.keys(C)) { const [kind, M, method, k] = key.split('|'); if (!['10', '20'].includes(k)) continue; (byCfg[kind + '|' + M] = byCfg[kind + '|' + M] || []).push([key, method, +k]); }
for (const cfg of Object.keys(byCfg)) {
  const [kind, M] = cfg.split('|'); const e = build(kind, +M);
  for (const [key, method, k] of byCfg[cfg]) {
    const per = [], bad = [];
    Q.forEach((x, qi) => {
      const cand = C[key][qi].map(id => e.reg.get(id)).filter(Boolean); const ts = [];
      let r; for (let rep = 0; rep < 3; rep++) { const tm = {}; r = decide(x.q, e, cand, tm); ts.push(tm.total); }
      per.push(med(ts)); if (!x.allowed.includes(r.set)) bad.push(x.q + ' -> ' + r.set + ' (want ' + x.allowed + ')');
    });
    const row = { kind, facts: e.reg.size, method, k, engine_p50_ms: med(per), engine_p95_ms: pct(per, .95), acc: (Q.length - bad.length) / Q.length, bad };
    out.push(row); console.log(kind, row.facts, method, k, 'engine p50', row.engine_p50_ms.toFixed(2), 'acc', (row.acc * 100).toFixed(1) + '%');
  }
}
fs.writeFileSync('results_cands.json', JSON.stringify(out, null, 1));
