import json, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
full=json.load(open('results_full.json')); vec=json.load(open('results_vec.json')); cand=json.load(open('results_cands.json'))
SURF='#fcfcfb'; INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
C=['#2a78d6','#eb6834','#1baf7a','#eda100']
plt.rcParams.update({'font.family':'DejaVu Sans','axes.edgecolor':GRID,'axes.labelcolor':INK2,'xtick.color':INK2,'ytick.color':INK2,'text.color':INK})
def get_v(kind,N,method,k): return next(r for r in vec if r['kind']==kind and r['facts']==N and r['method']==method and r['k']==k)
def get_c(kind,N,method,k): return next(r for r in cand if r['kind']==kind and r['facts']==N and r['method']==method and r['k']==k)
def get_f(kind,N): return next(r for r in full if r['kind']==kind and r['facts']==N)
def style(ax,title,sub):
    ax.set_facecolor(SURF); ax.grid(True,color=GRID,lw=.8); ax.set_axisbelow(True)
    for s in ('top','right'): ax.spines[s].set_visible(False)
    ax.set_title(title,loc='left',fontsize=14,fontweight='bold',color=INK,pad=26); ax.text(0,1.04,sub,transform=ax.transAxes,fontsize=10,color=INK2)
# chart 1: latency
kind='rand'; Ns=[r['facts'] for r in full if r['kind']==kind]
fig,ax=plt.subplots(figsize=(9,5.2),dpi=200,facecolor=SURF)
series=[('Full scan (current engine)',[get_f(kind,n)['p50_ms'] for n in Ns],C[0]),
 ('Sparse char n-gram cosine + engine (k=10)',[get_v(kind,n,'sparse',10)['p50_ms']+get_c(kind,n,'sparse',10)['engine_p50_ms'] for n in Ns[1:]],C[1]),
 ('Dense LSA-256 + engine (k=10)',[get_v(kind,n,'dense',10)['p50_ms']+get_c(kind,n,'dense',10)['engine_p50_ms'] for n in Ns[1:]],C[2])]
for i,(lab,ys,c) in enumerate(series):
    xs=Ns if i==0 else Ns[1:]
    ax.plot(xs,ys,color=c,lw=2,marker='o',ms=6,mec=SURF,mew=1.5,label=lab)
    ax.annotate(f'{ys[-1]:.0f} ms' if ys[-1]>=10 else f'{ys[-1]:.1f} ms',(xs[-1],ys[-1]),xytext=(8,0),textcoords='offset points',va='center',fontsize=9,color=INK2)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('Facts in the knowledge base (log scale)'); ax.set_ylabel('Median latency per query, ms (log scale)')
ax.set_xlim(15,400000); style(ax,'Latency grows linearly with a full scan','Median time per query, 165 test queries, 2 CPU cores, synthetic distractor facts')
ax.legend(frameon=False,loc='upper left',fontsize=9); fig.tight_layout(); fig.savefig('out/chart_latency.png'); plt.close(fig)
# chart 2: accuracy (hard case: 20% near-topic distractors)
kind='mix'; Ns=[r['facts'] for r in full if r['kind']==kind]
fig,ax=plt.subplots(figsize=(9,5.2),dpi=200,facecolor=SURF)
S=[('Full scan (current engine)',[100*get_f(kind,n)['acc'] for n in Ns],C[0],None),
   ('Sparse n-gram + engine, k=10',[100*get_c(kind,n,'sparse',10)['acc'] for n in Ns],C[1],None),
   ('Hybrid sparse+dense, k=20',[100*get_c(kind,n,'hybrid',20)['acc'] for n in Ns],C[2],None),
   ('Dense LSA-256 + engine, k=10',[100*get_c(kind,n,'dense',10)['acc'] for n in Ns],C[3],None)]
for lab,ys,c,_ in S:
    ax.plot(Ns,ys,color=c,lw=2,marker='o',ms=6,mec=SURF,mew=1.5,label=lab); ax.annotate(f'{ys[-1]:.1f}%',(Ns[-1],ys[-1]),xytext=(8,0),textcoords='offset points',va='center',fontsize=9,color=INK2)
ax.set_xscale('log'); ax.set_ylim(75,102); ax.set_xlim(800,400000); ax.set_xlabel('Facts in the knowledge base (log scale)'); ax.set_ylabel('Correct T/F/U verdicts, % of 165 queries')
style(ax,'A vector prefilter can lose the right fact','Hard case: 20% of the base are near-topic distractors ("Tariff X costs…", "Warranty on Y is…")')
ax.legend(frameon=False,loc='lower left',fontsize=9); fig.tight_layout(); fig.savefig('out/chart_accuracy.png'); plt.close(fig)
