// Line protocol for the Python benchmark: one JSON object per line in, one JSON answer per line out.
//  {mode:"gate", facts:[{id,text,K}], claims:[{fact_id,stance:"matches"|"contradicts"}]}  -> K-engine decision over stances given by an NLI model
//  {mode:"local", claim:"...", facts:[{id,text,K}]}                                      -> the website's own local analyzer + engine
const readline = require('readline'); const CL = require('./engine.js'); const { decide } = require('./pipeline.js');
function build(facts) { const e = new CL.Engine(); e.log.length = 0; for (const f of facts) e.reg.set(f.id, { id: f.id, text: f.text, K: f.K, t: 0, refs: [], history: [{ t: 0, K: f.K }], forced: null, sources: [] }); return e; }
const rl = readline.createInterface({ input: process.stdin });
rl.on('line', line => {
  if (!line.trim()) return;
  let r;
  try {
    const m = JSON.parse(line); const e = build(m.facts || []);
    if (m.mode === 'gate') { const cv = CL.evaluateClaims(m.claims, e); r = { set: cv.refuted.length ? 'F' : cv.confirmed.length ? 'T' : 'U' }; }
    else r = { set: decide(m.claim, e, e.facts()).set };
  } catch (err) { r = { set: 'U', error: String(err) }; }
  process.stdout.write(JSON.stringify(r) + '\n');
});
