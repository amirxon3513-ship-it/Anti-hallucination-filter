"""Live mode: the gateway answers ONLY from external sources it searches at question time. No stored knowledge base.

For every question:
  1. search external sources: by default only the TRUSTED tier (PubMed, Crossref: peer-reviewed / publisher-deposited records);
     Wikipedia is optional (--allow-wikipedia) and counts as a low-trust source,
  2. cut the results into sentences and keep those that relate to the question,
  3. every source page counts as one independent source; identical statements from several sources add up in K,
     conflicting ones lower it (same engine as the site),
  4. the gateway decides what is allowed (K >= 1), the model only words the answer, unsupported claims are dropped.

    python live_ask.py "Столица Узбекистана — Ташкент?"
    python live_ask.py "Сколько месяцев длится гарантия?" --provider openai     # uses a real model for wording

Needs internet. Standard library only. Written against the documented MediaWiki API and tested on a recorded
fixture only: the author's environment cannot reach wikipedia.org, so run it once and check the output.
Limits: pages of one site are separate sources but not fully independent; sentences are matched to the question by
word overlap. The scholarly sources are mostly English and cover science and medicine, not everyday facts: ask in English there,
and expect "no information" for questions they do not cover (that is the price of not trusting everything).
PubMed/Crossref connectors are written from the public API documentation and tested on recorded answers only.
"""
import json
import re
import xml.etree.ElementTree as ET
import urllib.parse
import urllib.request
from typing import Callable, Dict, List, Tuple

from contextual_gateway import ContextualGateway, RuleBasedLLM

UA = {"User-Agent": "AntiHallucinationFilter/0.1 (research prototype)"}


def http_get(url: str) -> dict:
    """JSON answers are parsed; anything else (PubMed efetch returns XML) comes back as {"_text": ...}."""
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
        body = r.read().decode("utf-8", "replace")
    try:
        return json.loads(body)
    except ValueError:
        return {"_text": body}


# ---------------------------------------------------------------- source connectors
def wikipedia(query: str, lang: str = "ru", n: int = 5, get: Callable = http_get) -> List[dict]:
    """-> [{"source": title, "url": ..., "text": intro extract}]"""
    url = (f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "generator": "search", "gsrsearch": query, "gsrlimit": n, "prop": "extracts|info",
        "exintro": 1, "explaintext": 1, "inprop": "url", "format": "json"}))
    pages = get(url).get("query", {}).get("pages", {})
    out = []
    for p in sorted(pages.values(), key=lambda x: x.get("index", 0)):
        if p.get("extract"):
            out.append({"source": f"{p['title']} (Википедия)", "url": p.get("fullurl", ""), "text": p["extract"], "kind": "external"})
    return out


# Trust tiers. A connector tags every document with "kind", which is the source class of the engine (official +3, external +1):
#   official  - peer-reviewed / publisher-deposited scholarly records (PubMed, Crossref): checked by editors before they exist
#   external  - open encyclopaedias anyone can edit (Wikipedia): useful context, NOT a reliable source on its own
# By default only the trusted tier is searched; Wikipedia has to be switched on explicitly (--allow-wikipedia).
def _text(node) -> str:
    return re.sub(r"\s+", " ", "".join(node.itertext())).strip() if node is not None else ""


def pubmed(query: str, lang: str = "ru", n: int = 5, get: Callable = http_get) -> List[dict]:
    """PubMed (US National Library of Medicine): titles and abstracts of peer-reviewed biomedical papers. Mostly English text."""
    base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    ids = get(base + "esearch.fcgi?" + urllib.parse.urlencode({"db": "pubmed", "term": query, "retmax": n, "retmode": "json", "sort": "relevance"}))
    ids = ids.get("esearchresult", {}).get("idlist", [])
    if not ids:
        return []
    xml = get(base + "efetch.fcgi?" + urllib.parse.urlencode({"db": "pubmed", "id": ",".join(ids), "retmode": "xml"})).get("_text", "")
    out = []
    for art in ET.fromstring(xml).iter("PubmedArticle"):
        pmid = _text(art.find(".//PMID"))
        title = _text(art.find(".//ArticleTitle"))
        abstract = " ".join(_text(a) for a in art.iterfind(".//Abstract/AbstractText"))
        if abstract:     # a title alone is not a statement
            out.append({"source": f"{title[:70]} (PubMed, PMID {pmid})", "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                        "text": abstract, "kind": "official"})
    return out


def crossref(query: str, lang: str = "ru", n: int = 5, get: Callable = http_get) -> List[dict]:
    """Crossref: metadata and, where the publisher deposited it, abstracts of scholarly works from thousands of publishers."""
    d = get("https://api.crossref.org/works?" + urllib.parse.urlencode({"query": query, "rows": n, "select": "title,abstract,URL,DOI,container-title"}))
    out = []
    for it in d.get("message", {}).get("items", []):
        title = (it.get("title") or [""])[0]
        abstract = re.sub(r"<[^>]+>", " ", it.get("abstract", ""))
        abstract = re.sub(r"\s+", " ", abstract).strip()
        if abstract:     # without an abstract there is no statement to check
            out.append({"source": f"{title[:70]} (Crossref, DOI {it.get('DOI', '')})", "url": it.get("URL", ""), "text": abstract, "kind": "official"})
    return out


TRUSTED: List[Callable] = [pubmed, crossref]
SOURCES: List[Callable] = list(TRUSTED)      # default: trusted tier only; add more connectors with the same signature


def active_sources(allow_wikipedia: bool = False) -> List[Callable]:
    return SOURCES + ([wikipedia] if allow_wikipedia else [])


# ---------------------------------------------------------------- sentences related to the question
def _stems(s: str) -> set:
    try:
        import cl_ml
        return cl_ml.stems(s)
    except ImportError:
        return {w[:5] for w in re.findall(r"[a-zа-яё]+", s.lower()) if len(w) >= 4}


def sentences(text: str) -> List[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-ZА-ЯЁ0-9«\"])|\n+", text) if len(s.strip()) >= 25]


def related(query: str, docs: List[dict], per_doc: int = 2, min_overlap: int = 2) -> List[Tuple[str, dict]]:
    q = _stems(query)
    picked = []
    for d in docs:
        scored = sorted(((len(q & _stems(s)), s) for s in sentences(d["text"])), reverse=True)
        picked += [(s, d) for sc, s in scored[:per_doc] if sc >= min_overlap]
    return picked


# ---------------------------------------------------------------- the live gateway
class LiveGateway:
    def __init__(self, llm=None, lang: str = "ru", get: Callable = http_get, allow_wikipedia: bool = False) -> None:
        self.llm = llm or RuleBasedLLM()
        self.lang, self.get, self.allow_wikipedia = lang, get, allow_wikipedia

    def ask(self, query: str):
        gw = ContextualGateway(self.llm)            # a fresh, empty gateway for every question
        docs: List[dict] = []
        for src in active_sources(self.allow_wikipedia):
            try:
                docs += src(query, self.lang, 5, self.get)
            except Exception as e:                  # one source failing must not break the answer
                print(f"[источник недоступен: {e}]")
        facts: Dict[str, dict] = {}
        for i, (text, d) in enumerate(related(query, docs), 1):
            fid = gw.ingest(f"live_{i}", text, d["source"], d.get("kind", "external"))
            facts.setdefault(fid, {"text": gw.text[fid], "urls": []})["urls"].append((d["source"], d["url"]))
        v = gw.ask(query)
        return v, gw, facts


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--lang", default="ru")
    ap.add_argument("--allow-wikipedia", action="store_true", help="also search Wikipedia (low trust tier, K +1 per page)")
    ap.add_argument("--provider", choices=["none", "anthropic", "openai", "gemini"], default="none")
    a = ap.parse_args()
    llm = None
    if a.provider != "none":
        from llm_adapters import make_llm
        llm = make_llm(a.provider)
    v, gw, facts = LiveGateway(llm, a.lang, allow_wikipedia=a.allow_wikipedia).ask(a.query)
    print(f"статус: {v.status}   K = {v.K}   множество: {v.set}")
    print(v.answer or {"paradox": "Информации нет: запрос парадоксален.", "ungrounded": "Информации нет: запрос ссылается на себя.",
                       "refuted": "Утверждение опровергнуто найденными источниками.", "no_info": "Информации нет: подтверждающих источников не найдено."}[v.status])
    for fid, f in facts.items():
        print(f"  K = {gw.system.K(fid):+d}  {f['text']}")
        for name, url in f["urls"]:
            print(f"      источник: {name}  {url}")
