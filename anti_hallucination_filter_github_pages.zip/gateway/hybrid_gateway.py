"""Three modes in one place: kb (your knowledge base only), live (external search only), hybrid (both).

    python hybrid_gateway.py state.json "Сколько дней действует возврат?" --mode hybrid
    python hybrid_gateway.py state.json "Столица Узбекистана — Ташкент?" --mode live
    python hybrid_gateway.py state.json "Гарантия на технику?" --mode kb

state.json is the file exported from the Anti-hallucination filter site (Интеграция -> Скачать JSON). Add --provider anthropic|openai|gemini
to let a real model word the answer (the gateway still decides what is allowed).

AUTO-LEARNING (hybrid mode, on by default): when an answer was built from external sources, the facts that made it into the
verified answer are written into the state file, so the next time the same question is answered from your own base.
  * new fact       -> saved with its sources and K (K comes from the sources, as everywhere else);
  * same fact already in your base, found by a new source -> the source is added and K grows (Axiom 3);
  * fact that CONFLICTS with your base -> saved as quarantined (K = 0, needs review); your own facts are never lowered
    automatically;
  * every saved fact carries `learned` = {url, query, at}; the file is backed up once as state.json.bak.
Use --no-learn to switch it off, --dry-run to see what would be saved, --learn-min-k N to save only facts with K >= N.

In hybrid mode all facts go into one engine: sources from your base and from the search add up in K, and the report lists
CONFLICTS between your base and external sources (for example an outdated internal document).
Needs internet for live/hybrid. Tested on recorded fixtures only: see live_gateway.py for the caveats.
"""
import hashlib
import json
import os
import shutil
import time
from typing import Callable

from contextual_gateway import ContextualGateway, RuleBasedLLM, relate
from live_gateway import active_sources, http_get, related


class HybridGateway:
    def __init__(self, state_path: str = "", llm=None, mode: str = "hybrid", lang: str = "ru", get: Callable = http_get,
                 learn: bool = True, dry_run: bool = False, learn_min_k: int = 1, learn_all: bool = False, allow_wikipedia: bool = False) -> None:
        assert mode in ("kb", "live", "hybrid")
        self.state, self.llm, self.mode, self.lang, self.get = state_path, llm or RuleBasedLLM(), mode, lang, get
        self.learn, self.dry_run, self.learn_min_k, self.learn_all = learn, dry_run, learn_min_k, learn_all
        self.learned = {"new": [], "confirmed": [], "quarantined": []}   # what the last ask() saved (or would save)
        self._kb_sources = {}
        self.allow_wikipedia = allow_wikipedia

    def _load_kb(self, gw: ContextualGateway) -> None:
        data = json.load(open(self.state, encoding="utf-8"))
        gw.sources = {}
        for f in data["facts"]:
            refs = [(r[1:], True) if r.startswith("!") else (r, False) for r in f.get("refs", [])]
            gw.add_fact(f["id"], f["text"], int(f["K"]), int(f.get("t", 0)), refs)
            gw.sources[f["id"]] = {s["name"] for s in f.get("sources", [])}
        self._kb_sources = {i: set(v) for i, v in gw.sources.items()}

    def ask(self, query: str):
        gw = ContextualGateway(self.llm)
        origin, conflicts = {}, []                     # fact id -> "база" | "внешний"
        if self.mode in ("kb", "hybrid"):
            self._load_kb(gw)
            origin = {i: "база" for i in gw.text}
        self.kinds = {}
        if self.mode in ("live", "hybrid"):
            docs = []
            for src in active_sources(self.allow_wikipedia):
                try:
                    docs += src(query, self.lang, 5, self.get)
                except Exception as e:
                    print(f"[источник недоступен: {e}]")
            self.kinds = {d["source"]: d.get("kind", "external") for d in docs}
            for i, (text, d) in enumerate(related(query, docs), 1):
                rel, other = relate(text, gw.text)
                if rel == "conflict" and other in origin and origin[other] == "база":
                    conflicts.append({"kb_fact": other, "kb_text": gw.text[other], "external": text, "source": d["source"], "url": d["url"]})
                fid = gw.ingest(f"live_{i}", text, d["source"], d.get("kind", "external"))
                if rel == "conflict" and other in origin and origin[other] == "база":
                    conflicts[-1]["ext_fact"] = fid
                origin.setdefault(fid, "внешний")
                gw.urls = getattr(gw, "urls", {})
                gw.urls.setdefault(fid, []).append((d["source"], d["url"]))
        v = gw.ask(query)
        # the answer must not contain both sides of a conflict: the side with the lower K is dropped (a tie favours your base)
        losers = set()
        for c in conflicts:
            a, b = c["kb_fact"], c.get("ext_fact")
            if b and b in gw.text:
                losers.add(b if gw.system.K(b) <= gw.system.K(a) else a)
        if losers and v.claims:
            v.claims = [c for c in v.claims if not (set(c["cites"]) & losers)]
            v.answer = " ".join(c["text"] for c in v.claims)
            if v.claims:
                v.K = min(gw.system.K(x) for c in v.claims for x in c["cites"])
            else:
                v.status, v.K = "no_info", 0
        self.learned = {"new": [], "confirmed": [], "quarantined": []}
        if self.learn and self.mode == "hybrid" and self.state:
            self._learn(query, v, gw, origin, conflicts)
        return v, gw, origin, conflicts

    # ---- auto-learning: external facts that were used in the answer become part of the base
    def _learn(self, query, v, gw, origin, conflicts) -> None:
        cited = {x for c in (v.claims or []) for x in c["cites"]}
        data = json.load(open(self.state, encoding="utf-8"))
        by_id = {f["id"]: f for f in data["facts"]}
        have_text = {f["text"].strip().lower() for f in data["facts"]}
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        conflicting = {c.get("ext_fact") for c in conflicts}
        urls = getattr(gw, "urls", {})

        W = {"official": 3, "internal": 2, "external": 1, "unverified": 0}

        def src_entries(names, cls=None, w=None):
            return [{"name": n, "cls": cls or self.kinds.get(n, "external"), "w": W[cls or self.kinds.get(n, "external")] if w is None else w, "against": False} for n in sorted(names)]

        # 1. facts of the base that got new confirming sources (same claim from another source)
        for fid, names in list(gw.sources.items()):
            if fid not in by_id or origin.get(fid) != "база":
                continue
            fresh = names - self._kb_sources.get(fid, set())
            if not fresh or (not self.learn_all and fid not in cited):
                continue
            f = by_id[fid]
            f["sources"] = (f.get("sources") or []) + src_entries(fresh)
            f["K"] = int(f["K"]) + sum(W[self.kinds.get(n, "external")] for n in fresh)
            f["t"] = int(f.get("t", 0)) + 1
            f["history"] = (f.get("history") or [{"t": 0, "K": f["K"] - sum(W[self.kinds.get(n, "external")] for n in fresh)}]) + [{"t": f["t"], "K": f["K"], "forced": False}]
            meta = f.setdefault("learned", {})
            meta["confirmed_by"] = sorted(set(meta.get("confirmed_by", [])) | fresh)
            self.learned["confirmed"].append({"id": fid, "text": f["text"], "K": f["K"], "added": sorted(fresh)})

        # 2. new external facts
        for fid in [i for i, o in origin.items() if o == "внешний"]:
            if not self.learn_all and fid not in cited and fid not in conflicting:
                continue
            text = gw.text[fid]
            if text.strip().lower() in have_text:
                continue
            names = gw.sources.get(fid) or {u[0] for u in urls.get(fid, [])}
            K = gw.system.K(fid)
            new_id = "web_" + hashlib.sha1(text.encode("utf-8")).hexdigest()[:8]
            url = (urls.get(fid) or [("", "")])[0][1]
            if fid in conflicting:     # never lower the user's own facts automatically: keep the claim aside for review
                rec = {"id": new_id, "text": text, "K": 0, "t": 0, "refs": [], "sources": src_entries(names, "unverified", 0),
                       "history": [{"t": 0, "K": 0}], "learned": {"url": url, "query": query, "at": now, "status": "needs_review"}}
                kind = "quarantined"
            elif K >= self.learn_min_k:
                rec = {"id": new_id, "text": text, "K": K, "t": 0, "refs": [], "sources": src_entries(names),
                       "history": [{"t": 0, "K": K}], "learned": {"url": url, "query": query, "at": now}}
                kind = "new"
            else:
                continue
            if new_id in by_id:
                continue
            data["facts"].append(rec); by_id[new_id] = rec; have_text.add(text.strip().lower())
            self.learned[kind].append({"id": new_id, "text": text, "K": rec["K"], "sources": sorted(names), "url": url})

        if self.dry_run or not any(self.learned.values()):
            return
        if not os.path.exists(self.state + ".bak"):
            shutil.copyfile(self.state, self.state + ".bak")
        data["exported"] = now
        tmp = self.state + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, self.state)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("state")
    ap.add_argument("query")
    ap.add_argument("--mode", choices=["kb", "live", "hybrid"], default="hybrid")
    ap.add_argument("--lang", default="ru")
    ap.add_argument("--provider", choices=["none", "anthropic", "openai", "gemini"], default="none")
    ap.add_argument("--allow-wikipedia", action="store_true", help="also search Wikipedia (low trust tier)")
    ap.add_argument("--no-learn", action="store_true", help="do not write external facts into the state file")
    ap.add_argument("--dry-run", action="store_true", help="show what would be learned, write nothing")
    ap.add_argument("--learn-min-k", type=int, default=1, help="save only facts whose K is at least this")
    ap.add_argument("--learn-all", action="store_true", help="also save external facts that were not used in the answer")
    a = ap.parse_args()
    llm = None
    if a.provider != "none":
        from llm_adapters import make_llm
        llm = make_llm(a.provider)
    hg = HybridGateway(a.state, llm, a.mode, a.lang, learn=not a.no_learn, dry_run=a.dry_run, learn_min_k=a.learn_min_k, learn_all=a.learn_all, allow_wikipedia=a.allow_wikipedia)
    v, gw, origin, conflicts = hg.ask(a.query)
    print(f"режим: {a.mode}   статус: {v.status}   K = {v.K}   множество: {v.set}")
    print(v.answer or {"paradox": "Информации нет: запрос парадоксален.", "ungrounded": "Информации нет: запрос ссылается на себя.",
                       "refuted": "Утверждение опровергнуто источниками.", "no_info": "Информации нет."}[v.status])
    shown = [c["cites"] for c in v.claims] if v.claims else []
    for fid in dict.fromkeys(i for cites in shown for i in cites):
        print(f"  [{origin.get(fid, '?')}] K = {gw.system.K(fid):+d}  {gw.text[fid]}")
    if conflicts:
        print("ПРОТИВОРЕЧИЯ между базой и внешними источниками:")
        for c in conflicts:
            print(f"  база ({c['kb_fact']}): {c['kb_text']}\n  внешний ({c['source']}): {c['external']}  {c['url']}")
    L = hg.learned
    if any(L.values()):
        print(("[пробный запуск, ничего не записано] " if a.dry_run else "") + f"В базу {'было бы ' if a.dry_run else ''}записано: новых {len(L['new'])}, подтверждений {len(L['confirmed'])}, на проверку {len(L['quarantined'])}")
        for kind, title in (("new", "новый факт"), ("confirmed", "подтверждён источником"), ("quarantined", "на проверку (противоречит базе)")):
            for x in L[kind]:
                print(f"  + {title}: K = {x['K']:+d}  {x['text']}")
