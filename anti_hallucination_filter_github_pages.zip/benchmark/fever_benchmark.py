#!/usr/bin/env python3
"""FEVER benchmark for the Anti-hallucination filter (run on Google Colab with a GPU, or anywhere with Python + Node).

FEVER: claims labelled SUPPORTS / REFUTES / NOT ENOUGH INFO against Wikipedia evidence. Mapping: SUPPORTS -> T, REFUTES -> F, NOT ENOUGH INFO -> U.
All evidence sentences of the sampled claims are pooled into one knowledge base (K = +1, source class "external"), so every claim must find
its evidence among thousands of distractors, and NOT-ENOUGH-INFO claims must be recognised as unsupported.

Three systems are scored on the same claims:
  1. local_engine : the website's own local analyzer + K-engine (rule based, no model)      -> the honest "as shipped" number
  2. nli_only     : retrieval + NLI model, argmax, no gate                                    -> baseline
  3. nli_plus_gate: retrieval + NLI stance + the K-engine decision (refuted wins, T only if a supporting fact and no refuting one)

Colab:
    !pip -q install datasets sentence-transformers
    !apt-get -qq install -y nodejs          # only if `node -v` fails
    (upload this folder or: git clone <your repo>, cd benchmark)
    !python fever_benchmark.py --n 1500 --device auto
Offline plumbing test (no models, no download):   python fever_benchmark.py --dummy --data_file fever_sample.jsonl
Writes results_fever.json  -> send it back and the Benchmark tab gets updated.
"""
import argparse, json, os, random, shutil, subprocess, sys, time, hashlib, re
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('--n', type=int, default=1500, help='claims to sample (balanced over the three labels)')
ap.add_argument('--k', type=int, default=5, help='evidence sentences retrieved per claim')
ap.add_argument('--tau', type=float, default=0.5, help='NLI probability needed to count as supporting / refuting')
ap.add_argument('--embed_model', default='intfloat/multilingual-e5-small')
ap.add_argument('--nli_model', default='cross-encoder/nli-deberta-v3-base')
ap.add_argument('--device', default='auto', choices=['auto', 'cpu', 'cuda'])
ap.add_argument('--batch', type=int, default=64)
ap.add_argument('--seed', type=int, default=7)
ap.add_argument('--data_file', default=None, help='jsonl with {claim,label,evidence:[str]} instead of downloading FEVER')
ap.add_argument('--dummy', action='store_true')
a = ap.parse_args()
HERE = os.path.dirname(os.path.abspath(__file__))
LAB = {'SUPPORTS': 'T', 'REFUTES': 'F', 'NOT ENOUGH INFO': 'U', 'NEI': 'U'}

# ------------------------------------------------------------------ data
def norm_label(v, feat=None):
    if isinstance(v, int) and feat is not None and hasattr(feat, 'names'): v = feat.names[v]
    return LAB.get(str(v).upper().replace('_', ' ').strip())

def ev_texts(rec):
    out = []
    for e in rec.get('evidence') or []:
        if isinstance(e, str): out.append(e)
        elif isinstance(e, dict):
            for k in ('text', 'sentence', 'evidence_text'):
                if isinstance(e.get(k), str): out.append(e[k]); break
        elif isinstance(e, (list, tuple)):
            strs = [x for x in e if isinstance(x, str) and len(x) > 3]
            if strs: out.append(max(strs, key=len))
    return [re.sub(r'\s+', ' ', t).strip() for t in out if t and len(t.strip()) > 3]

def load_data():
    if a.data_file:
        rows = [json.loads(l) for l in open(a.data_file, encoding='utf8') if l.strip()]
        return [dict(claim=r['claim'], y=LAB[r['label'].upper()], ev=ev_texts(r)) for r in rows]
    from datasets import load_dataset
    last = None
    for name, split in (('copenlu/fever_gold_evidence', 'validation'), ('copenlu/fever_gold_evidence', 'test'), ('copenlu/fever_gold_evidence', 'train')):
        try:
            ds = load_dataset(name, split=split); break
        except Exception as e:
            last = e; ds = None
    if ds is None: sys.exit(f'Could not load FEVER from the Hugging Face hub: {last}\nPaste this message to the assistant.')
    feat = ds.features.get('label') if hasattr(ds, 'features') else None
    rows, bad = [], 0
    for r in ds:
        y = norm_label(r.get('label'), feat)
        if y is None: bad += 1; continue
        rows.append(dict(claim=r['claim'], y=y, ev=ev_texts(r)))
    if not rows: sys.exit('No usable rows. First record was:\n' + json.dumps(dict(ds[0]), default=str)[:1500])
    print(f'loaded {len(rows)} claims from {name}/{split} ({bad} with unknown label)')
    if not any(r['ev'] for r in rows):
        sys.exit('No evidence text found. First record was:\n' + json.dumps(dict(ds[0]), default=str)[:1500])
    return rows

rows = load_data(); R = random.Random(a.seed); by = {'T': [], 'F': [], 'U': []}
for r in rows: by[r['y']].append(r)
per = a.n // 3; sample = []
for y in 'TFU': R.shuffle(by[y]); sample += by[y][:per]
R.shuffle(sample)
pool, pid = [], {}
for r in sample:
    for t in r['ev']:
        if t not in pid: pid[t] = len(pool); pool.append(t)
print(f'{len(sample)} claims, {len(pool)} pooled evidence sentences, labels: ' + ', '.join(f"{y}={sum(1 for r in sample if r['y']==y)}" for y in 'TFU'))

# ------------------------------------------------------------------ models
dev = a.device
if not a.dummy:
    import torch
    if dev == 'auto': dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    if dev == 'cuda' and not torch.cuda.is_available(): sys.exit('--device cuda but no GPU is visible')
else: dev = 'cpu'
gpu_name = None
if dev == 'cuda': import torch; gpu_name = torch.cuda.get_device_name(0)
sync = (lambda: __import__('torch').cuda.synchronize()) if dev == 'cuda' else (lambda: None)
print('device:', dev, gpu_name or '')

TOK = lambda s: re.findall(r'[a-z0-9]+', s.lower())
class DummyEnc:
    def encode(self, xs, **kw):
        out = np.zeros((len(xs), 256), np.float32)
        for i, s in enumerate(xs):
            for w in TOK(s): out[i, int(hashlib.md5(w.encode()).hexdigest()[:6], 16) % 256] += 1
        return out / (np.linalg.norm(out, axis=1, keepdims=True) + 1e-9)
def dummy_nli(pairs):     # lexical stand-in, ONLY for the offline plumbing test
    res = []
    for prem, hyp in pairs:
        p, h = set(TOK(prem)), set(TOK(hyp)); ov = len(p & h) / (len(h) or 1)
        nums_h = {w for w in h if w.isdigit()}; nums_p = {w for w in p if w.isdigit()}
        neg_h = bool(h & {'not', 'never', 'no'}); neg_p = bool(p & {'not', 'never', 'no'})
        if ov >= .6 and (nums_h and nums_p and not nums_h & nums_p or neg_h != neg_p): res.append([.05, .9, .05])
        elif ov >= .8: res.append([.9, .05, .05])
        elif ov >= .6: res.append([.05, .15, .8])
        else: res.append([.1, .1, .8])
    return np.array(res, np.float32)                 # order: entail, contra, neutral

if a.dummy: enc = DummyEnc(); nli = None
else:
    from sentence_transformers import SentenceTransformer, CrossEncoder
    enc = SentenceTransformer(a.embed_model, device=dev)
    nli = CrossEncoder(a.nli_model, device=dev)
    id2l = {int(i): str(l).lower() for i, l in nli.model.config.id2label.items()}
    order = [next(i for i, l in id2l.items() if k in l) for k in ('entail', 'contra', 'neutral')]
    print('NLI label order (entail, contra, neutral) =', order, id2l)
e5 = (not a.dummy) and 'e5' in a.embed_model

def nli_probs(pairs):
    if a.dummy: return dummy_nli(pairs)
    import torch
    sc = nli.predict(pairs, batch_size=a.batch, apply_softmax=True, show_progress_bar=False)
    return np.asarray(sc, np.float32)[:, order]

# ------------------------------------------------------------------ run
timing = {'device': dev, 'gpu': gpu_name, 'embed_model': 'dummy' if a.dummy else a.embed_model, 'nli_model': 'dummy' if a.dummy else a.nli_model}
sync(); t = time.perf_counter()
E = enc.encode([('passage: ' if e5 else '') + x for x in pool], batch_size=a.batch, normalize_embeddings=True).astype(np.float32); sync()
timing['embed_pool_s'] = time.perf_counter() - t; timing['embed_facts_per_s'] = len(pool) / timing['embed_pool_s']
sync(); t = time.perf_counter()
QE = enc.encode([('query: ' if e5 else '') + r['claim'] for r in sample], batch_size=a.batch, normalize_embeddings=True).astype(np.float32); sync()
timing['embed_claims_s'] = time.perf_counter() - t
t = time.perf_counter(); S = QE @ E.T; top = np.argsort(-S, axis=1)[:, :a.k]; timing['retrieval_ms_per_claim'] = (time.perf_counter() - t) * 1000 / len(sample)
hit = np.mean([bool(set(pid[x] for x in r['ev']) & set(top[i])) for i, r in enumerate(sample) if r['ev']]); timing['evidence_recall_at_k'] = float(hit)

pairs = [(pool[j], sample[i]['claim']) for i in range(len(sample)) for j in top[i]]
sync(); t = time.perf_counter(); P = nli_probs(pairs); sync()
timing['nli_pairs'] = len(pairs); timing['nli_s'] = time.perf_counter() - t; timing['nli_pairs_per_s'] = len(pairs) / timing['nli_s']
P = P.reshape(len(sample), a.k, 3)

node = shutil.which('node')
if not node: sys.exit('Node.js is needed for the K-engine: apt-get install nodejs')
cli = subprocess.Popen([node, os.path.join(HERE, 'engine_cli.js')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, cwd=HERE)
def engine(msg):
    cli.stdin.write(json.dumps(msg) + '\n'); cli.stdin.flush(); return json.loads(cli.stdout.readline())['set']

pred = {'local_engine': [], 'nli_only': [], 'nli_plus_gate': []}; lat = []
for i, r in enumerate(sample):
    facts = [dict(id=f'p{j}', text=pool[j], K=1) for j in top[i]]
    pred['local_engine'].append(engine(dict(mode='local', claim=r['claim'], facts=facts)))
    ent, con = P[i, :, 0], P[i, :, 1]
    pred['nli_only'].append('T' if ent.max() > con.max() and ent.max() > a.tau else 'F' if con.max() > a.tau else 'U')
    t = time.perf_counter()
    claims = [dict(fact_id=f'p{j}', stance='matches' if ent[m] > a.tau else 'contradicts') for m, j in enumerate(top[i]) if ent[m] > a.tau or con[m] > a.tau]
    pred['nli_plus_gate'].append(engine(dict(mode='gate', facts=facts, claims=claims))); lat.append((time.perf_counter() - t) * 1000)
cli.stdin.close(); cli.wait(timeout=5)
timing['gate_ms_per_claim_p50'] = float(np.median(lat)); timing['gate_ms_per_claim_p95'] = float(np.percentile(lat, 95))

def metrics(pr):
    y = [r['y'] for r in sample]; acc = np.mean([p == t for p, t in zip(pr, y)]); f1 = []
    for c in 'TFU':
        tp = sum(p == c and t == c for p, t in zip(pr, y)); fp = sum(p == c and t != c for p, t in zip(pr, y)); fn = sum(p != c and t == c for p, t in zip(pr, y))
        f1.append(2 * tp / (2 * tp + fp + fn) if tp else 0.0)
    nonT = [(p, t) for p, t in zip(pr, y) if t != 'T']
    return dict(accuracy=float(acc), macro_f1=float(np.mean(f1)), false_admit_rate=float(np.mean([p == 'T' for p, t in nonT])),
                supports_recall=float(np.mean([p == 'T' for p, t in zip(pr, y) if t == 'T'])),
                confusion={f'{t}>{p}': sum(1 for pp, tt in zip(pr, y) if tt == t and pp == p) for t in 'TFU' for p in 'TFU'})
out = dict(config=dict(n=len(sample), pool=len(pool), k=a.k, tau=a.tau, seed=a.seed, dummy=a.dummy), timing=timing,
           systems={k: metrics(v) for k, v in pred.items()},
           examples={k: [dict(claim=sample[i]['claim'], gold=sample[i]['y'], pred=v[i]) for i in range(len(sample)) if v[i] != sample[i]['y']][:25] for k, v in pred.items()})
json.dump(out, open('results_fever.json', 'w'), indent=1, ensure_ascii=False)
print(json.dumps(dict(timing=timing, systems={k: {m: round(x, 3) for m, x in v.items() if m != 'confusion'} for k, v in out['systems'].items()}), indent=1))
print('wrote results_fever.json')
