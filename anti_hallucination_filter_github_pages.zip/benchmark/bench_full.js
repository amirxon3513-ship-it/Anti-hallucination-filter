// Full scan: the engine looks through every fact of the base (what the site does now).
const fs = require('fs'); const CL = require('./engine.js'); const loadPresets = require('./presets.js'); const { decide, now } = require('./pipeline.js');
const Q = require('./queries.json'); const D = JSON.parse(fs.readFileSync('distractors.json', 'utf8'));
const med = a => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * p))]; };
function build(kind, M) {
  const e = new CL.Engine(); loadPresets(e);
  const nNear = kind === 'mix' ? Math.floor(M * 0.2) : 0, nRand = M - nNear;
  e.log.length = 0;
  for (const d of D.rand.slice(0, nRand).concat(D.near.slice(0, nNear))) e.reg.set(d.id, { id: d.id, text: d.text, K: d.K, t: 0, refs: [], history: [{ t: 0, K: d.K }], forced: null, sources: [] });
  return e;
}
const sizes = [0, 1000, 10000, 50000, 100000], reps = +process.argv[2] || 3, out = [];
for (const kind of ['rand', 'mix']) for (const M of sizes) {
  if (kind === 'mix' && M === 0) continue;
  const e = build(kind, M), facts = e.facts(), per = [], bad = [];
  for (const x of Q) {
    const ts = []; let r;
    for (let k = 0; k < reps; k++) { const tm = {}; r = decide(x.q, e, facts, tm); ts.push(tm); }
    per.push({ total: med(ts.map(t => t.total)), analyze: med(ts.map(t => t.analyze || t.total)) });
    if (!x.allowed.includes(r.set)) bad.push(x.q + ' -> ' + r.set);
  }
  const tot = per.map(p => p.total), an = per.map(p => p.analyze);
  const row = { kind, facts: facts.length, p50_ms: med(tot), p95_ms: pct(tot, .95), mean_ms: tot.reduce((a, b) => a + b, 0) / tot.length, analyze_p50_ms: med(an), acc: (Q.length - bad.length) / Q.length, bad };
  out.push(row); console.log(kind, row.facts, 'p50', row.p50_ms.toFixed(2), 'p95', row.p95_ms.toFixed(2), 'acc', (row.acc * 100).toFixed(1) + '%', bad.length ? 'bad:' + bad.length : '');
}
fs.writeFileSync('results_full.json', JSON.stringify(out, null, 1));
