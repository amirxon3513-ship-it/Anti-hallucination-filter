import json, time, sys, numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import MiniBatchKMeans
t00=time.time()
Q=json.load(open('queries.json',encoding='utf8')); gold=json.load(open('gold.json'))
P=json.load(open('preset_facts.json',encoding='utf8')); D=json.load(open('distractors.json',encoding='utf8'))
def corpus(kind,M):
    n_near = int(M*0.2) if kind=='mix' else 0
    return P + D['rand'][:M-n_near] + D['near'][:n_near]
full = P + D['rand'] + D['near']
texts=[f['text'] for f in full]; idpos={f['id']:i for i,f in enumerate(full)}
t=time.time()
vec=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,max_features=300000,dtype=np.float32,lowercase=True)
X=vec.fit_transform(texts); t_tfidf=time.time()-t
t=time.time(); svd=TruncatedSVD(256,algorithm='randomized',n_iter=3,random_state=0); Z=svd.fit_transform(X).astype(np.float32); t_svd=time.time()-t
Z/= (np.linalg.norm(Z,axis=1,keepdims=True)+1e-9)
print('fit tfidf %.1fs svd %.1fs  X nnz %d'%(t_tfidf,t_svd,X.nnz),flush=True)
QX=vec.transform([q['q'] for q in Q]); QZ=svd.transform(QX).astype(np.float32); QZ/=(np.linalg.norm(QZ,axis=1,keepdims=True)+1e-9)
ids_full=[f['id'] for f in full]
def topk_dense(M,qz,k,sub): s=M@qz; k=min(k,len(s)); i=np.argpartition(-s,k-1)[:k]; i=i[np.argsort(-s[i])]; return sub[i]
res=[]; cands={}
for kind,Ms in (('rand',[0,1000,10000,50000,100000]),('mix',[1000,10000,50000,100000])):
    for M in Ms:
        n_near=int(M*0.2) if kind=='mix' else 0
        sub=np.array(list(range(len(P)))+list(range(len(P),len(P)+M-n_near))+list(range(len(P)+100000,len(P)+100000+n_near)))
        Xs=X[sub]; Zs=Z[sub]; N=len(sub)
        # IVF index on dense vectors
        t=time.time(); nl=max(4,int(np.sqrt(N))); km=MiniBatchKMeans(nl,random_state=0,n_init=1,batch_size=4096,max_iter=20).fit(Zs); lab=km.labels_; cen=km.cluster_centers_.astype(np.float32); lists=[np.where(lab==c)[0] for c in range(nl)]; t_ivf=time.time()-t
        for method in ('sparse','dense','ivf','hybrid'):
            for k in (5,10,20):
                lat=[]; rec=[]; cl=[]
                for qi in range(len(Q)):
                    t=time.perf_counter()
                    if method=='sparse':
                        s=(Xs@QX[qi].T).toarray().ravel(); kk=min(k,len(s)); i=np.argpartition(-s,kk-1)[:kk]; top=sub[i[np.argsort(-s[i])]]
                    elif method=='dense': top=topk_dense(Zs,QZ[qi],k,sub)
                    elif method=='ivf':
                        cs=np.argsort(-(cen@QZ[qi]))[:8]; cand=np.concatenate([lists[c] for c in cs]); s=Zs[cand]@QZ[qi]; kk=min(k,len(s)); i=np.argpartition(-s,kk-1)[:kk]; top=sub[cand[i[np.argsort(-s[i])]]]
                    else:
                        s1=(Xs@QX[qi].T).toarray().ravel(); kk=min(k,len(s1)); i1=np.argpartition(-s1,kk-1)[:kk]
                        s2=Zs@QZ[qi]; kk2=min(k,len(s2)); i2=np.argpartition(-s2,kk2-1)[:kk2]; top=sub[np.unique(np.concatenate([i1,i2]))]
                    lat.append((time.perf_counter()-t)*1000)
                    c=[ids_full[j] for j in top]; cl.append(c)
                    if gold[qi]: rec.append(len(set(gold[qi])&set(c))/len(gold[qi]))
                row=dict(kind=kind,facts=N,method=method,k=k,p50_ms=float(np.median(lat)),p95_ms=float(np.percentile(lat,95)),recall=float(np.mean(rec)),full_recall=float(np.mean([1.0 if set(g)<=set(c) else 0.0 for g,c in zip(gold,cl) if g])),build_ivf_s=t_ivf if method=='ivf' else 0.0)
                res.append(row); cands[f'{kind}|{M}|{method}|{k}']=cl
        print(kind,N,[ (r['method'],r['k'],round(r['p50_ms'],2),round(r['full_recall'],3)) for r in res[-12:] if r['k']==10],flush=True)
json.dump(res,open('results_vec.json','w'),indent=1); json.dump(cands,open('candidates.json','w'),ensure_ascii=False)
print('done',time.time()-t00)
