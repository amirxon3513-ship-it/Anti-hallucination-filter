#!/usr/bin/env python3
"""CPU vs GPU benchmark for the vector prefilter of the Anti-hallucination filter.

Run on Google Colab (GPU runtime) or a Nebius GPU VM:
    pip install sentence-transformers faiss-cpu          # (faiss-gpu if you want GPU search too)
    python gpu_benchmark.py --model intfloat/multilingual-e5-small --facts 100000 --device both
    python gpu_benchmark.py --dummy                      # plumbing check without any model (hash vectors)

Needs in the same folder: queries.json, gold.json, preset_facts.json, distractors.json (made by gen_distractors.py).
Measures: embedding throughput (facts/s) on CPU and GPU, index build time, query latency p50/p95,
recall of the facts the K-engine needs (gold.json) among the top-k hits. Writes results_gpu.json.
"""
import argparse, json, time, sys, hashlib
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('--model', default='intfloat/multilingual-e5-small')
ap.add_argument('--facts', type=int, default=20000, help='number of distractor facts added to the 21 preset facts')
ap.add_argument('--device', default='both', choices=['cpu', 'cuda', 'both'])
ap.add_argument('--batch', type=int, default=256)
ap.add_argument('--k', type=int, default=10)
ap.add_argument('--dummy', action='store_true')
a = ap.parse_args()

Q = json.load(open('queries.json', encoding='utf8')); gold = json.load(open('gold.json'))
P = json.load(open('preset_facts.json', encoding='utf8')); D = json.load(open('distractors.json', encoding='utf8'))
facts = P + D['rand'][:int(a.facts * .8)] + D['near'][:int(a.facts * .2)]
texts = [f['text'] for f in facts]; ids = [f['id'] for f in facts]
print(f'{len(facts)} facts, {len(Q)} queries')

class Dummy:                       # deterministic hashed bag of character trigrams -> 256 dims (NOT a real embedding)
    def encode(self, xs, batch_size=0, normalize_embeddings=True, show_progress_bar=False, **kw):
        out = np.zeros((len(xs), 256), np.float32)
        for i, s in enumerate(xs):
            s = s.lower()
            for j in range(len(s) - 2): out[i, int(hashlib.md5(s[j:j + 3].encode()).hexdigest()[:6], 16) % 256] += 1
        return out / (np.linalg.norm(out, axis=1, keepdims=True) + 1e-9)

def load(device):
    if a.dummy: return Dummy()
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(a.model, device=device)

def prefix(kind):                  # e5 models want "query: " / "passage: "
    return ('query: ' if kind == 'q' else 'passage: ') if 'e5' in a.model and not a.dummy else ''

def search_fn(E):
    try:
        import faiss
        idx = faiss.IndexFlatIP(E.shape[1]); idx.add(E)
        return 'faiss', lambda q, k: idx.search(q[None, :], k)[1][0]
    except Exception:
        return 'numpy', lambda q, k: np.argsort(-(E @ q))[:k]

devices = ['cpu', 'cuda'] if a.device == 'both' else [a.device]
if a.dummy: devices = ['cpu']
results = []
for dev in devices:
    try:
        m = load(dev)
    except Exception as e:
        print(f'[{dev}] cannot load model: {e}'); continue
    if dev == 'cuda':
        import torch
        if not torch.cuda.is_available(): print('no CUDA device, skipping'); continue
        m.encode(['warm up'] * 8, batch_size=8)          # warm-up so CUDA init is not counted
        torch.cuda.synchronize()
    t = time.perf_counter()
    E = m.encode([prefix('p') + x for x in texts], batch_size=a.batch, normalize_embeddings=True, show_progress_bar=False).astype(np.float32)
    if dev == 'cuda': torch.cuda.synchronize()
    t_emb = time.perf_counter() - t
    t = time.perf_counter(); backend, search = search_fn(E); t_idx = time.perf_counter() - t
    lat, rec, full = [], [], []
    for qi, q in enumerate(Q):
        t = time.perf_counter()
        qv = m.encode([prefix('q') + q['q']], normalize_embeddings=True)[0].astype(np.float32)
        if dev == 'cuda': torch.cuda.synchronize()
        top = search(qv, a.k); lat.append((time.perf_counter() - t) * 1000)
        got = {ids[j] for j in top}
        if gold[qi]: rec.append(len(set(gold[qi]) & got) / len(gold[qi])); full.append(float(set(gold[qi]) <= got))
    row = dict(device=dev, model='dummy-hash' if a.dummy else a.model, facts=len(facts), embed_s=t_emb, facts_per_s=len(facts) / t_emb,
               index_s=t_idx, search_backend=backend, query_p50_ms=float(np.median(lat)), query_p95_ms=float(np.percentile(lat, 95)),
               recall_at_k=float(np.mean(rec)), gold_fully_found=float(np.mean(full)), k=a.k)
    results.append(row); print(json.dumps(row, indent=1))
if len(results) == 2: print(f"GPU speed-up for embedding: x{results[1]['facts_per_s'] / results[0]['facts_per_s']:.1f}")
json.dump(results, open('results_gpu.json', 'w'), indent=1)
