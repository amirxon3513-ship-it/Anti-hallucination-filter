const fs=require('fs'); const CL=require('./engine.js');
function loadPresets(engine){
  const body=fs.readFileSync(__dirname+'/presets_fn.txt','utf8');
  const fn=new Function('engine','CL', body.replace('function loadPresets()','return (function()')+')()');
  fn(engine,CL); return engine;
}
module.exports=loadPresets;
