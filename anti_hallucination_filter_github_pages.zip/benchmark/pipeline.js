// the same decision pipeline as the site (single statement): loop/self-reference -> analysis -> K evaluation -> T/F/U
const CL = require('./engine.js');
const now = () => Number(process.hrtime.bigint()) / 1e6;
function decide(query, engine, facts, timing) {
  let t0 = now();
  if (CL.localLoop(query) || CL.localSelfRef(query)) { if (timing) timing.total = now() - t0; return { set: 'U', ids: [] }; }
  const a = CL.localAnalyze(query, facts);
  let t1 = now();
  const ev = CL.evaluateQuery(a);
  if (ev.blocked) { if (timing) { timing.analyze = t1 - t0; timing.total = now() - t0; } return { set: 'U', ids: [] }; }
  const cv = CL.evaluateClaims(a.claims, engine);
  let t2 = now();
  let res;
  if (cv.refuted.length) res = { set: 'F', ids: [cv.refuted[0].fact.id] };
  else {
    const cls = engine.classify(a.relevant_ids);
    if (cls.T.length) res = { set: 'T', ids: cls.T.map(f => f.id) };
    else if (cls.F.length) res = { set: 'F', ids: cls.F.map(f => f.id) };
    else res = { set: 'U', ids: [] };
  }
  let t3 = now();
  if (timing) { timing.analyze = t1 - t0; timing.evaluate = t2 - t1; timing.classify = t3 - t2; timing.total = t3 - t0; }
  res.claimIds = (a.claims || []).map(c => c.fact_id); res.rel = a.relevant_ids || [];
  return res;
}
module.exports = { decide, now };
