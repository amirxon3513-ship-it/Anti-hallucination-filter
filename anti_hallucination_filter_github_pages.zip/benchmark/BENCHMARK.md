# Anti-hallucination filter — benchmark

All numbers below were measured by the scripts in this folder (CPU only: 2 cores, 7 GB RAM, Node 22 / Python 3.13).
The K-engine is the **same JavaScript code that runs on the website**, extracted unchanged from the page (`engine.js`).

## What was measured
- **Test queries:** 165 (the project's own test sets S1–S8: true / false / unknown facts, paradoxes, prompt injections, price and policy questions).
- **Knowledge base:** the 21 demo facts + synthetic distractor facts (invented names and numbers, so they cannot be true or false facts about the world).
  Two variants: `rand` (unrelated topics) and `mix` (80% unrelated + 20% *near-topic* look-alikes such as "Tariff X costs …", "Warranty on Y is …").
- **Verdict is correct** when the T/F/U result is in the set allowed for that query.

## 1. Speed of the engine, full scan (what the site does today)
| Facts in base | median ms / query | p95 ms | correct verdicts |
|---|---|---|---|
| 21 | 0.28 | 2.0 | 165/165 |
| 1 021 | 2.2 | 3.2 | 165/165 |
| 10 021 | 19.7 | 33 | 165/165 |
| 50 021 | 105 | 181 | 165/165 |
| 100 021 | 280 | 443 | 165/165 |

Accuracy does not degrade with base size (also on the `mix` variant: 100% up to 100 021 facts). Latency grows linearly, because retrieval scans every fact. The decision step itself (K evaluation, T/F/U split) is negligible: ~0.1 ms.

## 2. Vector prefilter in front of the K-engine
Retrieval picks top-k candidate facts, the K-engine decides over those only. No neural model could be downloaded in the test environment, so the vectors are:
- **sparse**: TF-IDF over character 3–5-grams, exact cosine (scipy);
- **dense**: the same TF-IDF reduced to 256 dimensions with SVD (LSA), exact cosine (numpy) — *this is not a neural embedding*;
- **hybrid**: union of the two top-k lists.

Latency at 100 021 facts (retrieval + engine, median):
| method | ms | verdicts correct (`rand`) | verdicts correct (`mix`) |
|---|---|---|---|
| full scan (baseline) | 280 | 100% | 100% |
| sparse, k=10 | 52 | 100% | 94.5% |
| hybrid, k=20 | 58 | 100% | 96.4% |
| dense LSA-256, k=10 | 8.8 | 94.5% | 84.2% |

An untuned IVF index (8 of 316 lists probed) took 1 ms but found the right facts in only 48% of cases; it is not recommended without tuning.

**Main finding.** When look-alike facts crowd the correct fact out of the top-k, the engine sees only the look-alikes and can *confirm* a wrong statement
(e.g. "Warranty on equipment is 12 months" is confirmed by a fact about a screen's warranty). So the prefilter must be high-recall (hybrid, k≥20), re-rank by
subject words, or the engine must require full coverage of the query's key nouns. Full scan has no such failure.

## 3. GPU
No GPU was available in the test environment, so **no GPU numbers are claimed**. `gpu_benchmark.py` measures embedding throughput (facts/s) on CPU vs CUDA,
FAISS/numpy search latency and the recall of the facts the engine needs, with a real model (default `intfloat/multilingual-e5-small`; `BAAI/bge-m3` also works).
Plumbing was checked with `--dummy` (hash vectors); it has not been run with a real model yet. The K-engine itself does not use a GPU; the GPU helps only
embedding / NLI / LLM steps.

## Limitations
- Distractors are synthetic; queries are the project's own and were used while developing the rules, so 100% at 21 facts is not an independent result.
- Node.js, not a browser; 2 CPU cores shared with other jobs during some runs.
- Dense vectors here are LSA, much weaker than a neural embedding. Real embeddings are expected to do better, which must be verified with `gpu_benchmark.py`.

## Reproduce
```
node bench_full.js 2          # section 1  -> results_full.json
python3 gen_distractors.py    # synthetic facts
python3 vec.py                # section 2: retrieval  -> results_vec.json, candidates.json
node bench_cands.js           # section 2: engine over candidates -> results_cands.json
python3 plot.py               # charts in out/
python3 gpu_benchmark.py --device both   # section 3, on a GPU machine
```

## English FEVER-style set (hand-written, not FEVER)
150 claims, 60 pooled facts (`fever_style_en.jsonl`, built by `build_en_fever_style.py`). Blind first pass, no rule tuning:
accuracy 85.3% (T 91.7 / F 83.3 / U 76.7), false admits 3/90 (3.3%), median 0.24 ms. Run: `node en_fever_style.js ./engine.js out.json`.
Speed and accuracy tables above were measured before the English rule layer was added.
After general English fixes (ordinals, strict coverage on number mismatch, weak-match guard; `results_en_fever_style_after_fixes.json`): accuracy 90.0%, false admits 1/90 (1.1%). Not blind any more. Russian sets 165/165.
