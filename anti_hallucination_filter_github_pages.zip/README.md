# Anti-hallucination filter

A gateway that stops a RAG system from answering with things it cannot support. Built on the author's own **Contextual Logic** framework:
every statement gets an integer context **K ∈ ℤ** and falls into one of three sets, and only the verified one reaches the language model.

| Set | Rule | What happens |
|---|---|---|
| **T** (true) | K ≥ 1 | admitted to the answer, with a source id for every claim |
| **U** (unknown) | K = 0 | paradoxes, self-reference, unverified data: quarantined, the filter answers "no information" |
| **F** (false) | K ≤ −1 | blocked, never reaches the model |

The decision is made by a **deterministic engine**, not by a language model. The model only parses the query and phrases the answer from already admitted facts;
any claim in the answer without a reference to a fact with K ≥ 1 is removed.

**Live demo:** `https://<your-username>.github.io/<repository-name>/` (Russian: `index.html`, English: `index_en.html`)

## What is in the repository
| Path | Contents |
|---|---|
| `index.html`, `index_en.html` | the whole app (engine, knowledge base, UI, benchmark tab) as static pages, Russian and English |
| `theory.html`, `theory_en.html` | axioms, definitions and the theorem that forbids singularities |
| `gateway/` | Python modules for your own RAG: `contextual_gateway.py`, `cl_ml.py`, `cl_model.json`, `live_gateway.py`, `hybrid_gateway.py`, `external_sources.py`, `llm_adapters.py`, `ask.py` |
| `benchmark/` | scripts, test queries, raw results and charts (see `benchmark/BENCHMARK.md`) |
| `media/` | demo video: several statements checked in one run |
| `assets/thumbnail.png` | project thumbnail |

## Run it
- **Website:** open `index.html` (no build step, no dependencies).
- **Python gateway:** Python 3.8+, no packages needed. `python gateway/live_gateway.py "Столица Узбекистана — Ташкент?"`
- **Benchmark:** `node benchmark/bench_full.js 2` (Node 22), `python3 benchmark/vec.py` (numpy, scipy, scikit-learn).

## Honest status
- **Prototype.** The axioms and the K-engine are exact; the part that turns free text into "which fact is this about and does it confirm or refute it" is rule-based and weaker.
  On queries not seen during development the local mode was correct in about 88% of cases (44 of 50). It is tuned for Russian; the "Claude AI" mode (inside Claude only) handles other phrasings.
- The theory has not been independently peer-reviewed.
- Benchmarks use synthetic distractor facts, ran in Node on two CPU cores, and include **no GPU numbers** yet (`benchmark/gpu_benchmark.py` is ready for a GPU machine).
- Live source modules (PubMed, Crossref, optional Wikipedia) were written without network access in the build environment and are not verified against the real services.

## Based on
"Contextual Logic: An Axiomatic Framework for Neutralizing Self-Referential Paradoxes and Computational Hallucinations" (author's paper).
