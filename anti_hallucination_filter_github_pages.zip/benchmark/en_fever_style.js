// Hand-written English set in FEVER style. The whole pool of 60 evidence sentences is the knowledge base (K=+1); the engine decides each claim.
const fs = require('fs'); const CL = require(process.argv[2] || './engine.js'); const { decide, now } = require('./pipeline.js');
const rows = fs.readFileSync('fever_style_en.jsonl', 'utf8').trim().split('\n').map(JSON.parse); const LAB = { SUPPORTS: 'T', REFUTES: 'F', 'NOT ENOUGH INFO': 'U' };
const pool = [...new Set(rows.flatMap(r => r.evidence))]; const e = new CL.Engine(); e.log.length = 0;
pool.forEach((t, i) => e.reg.set('p' + i, { id: 'p' + i, text: t, K: 1, t: 0, refs: [], history: [{ t: 0, K: 1 }], forced: null, sources: [] })); const facts = e.facts();
const conf = {}, bad = [], ts = []; let ok = 0;
for (const r of rows) { const y = LAB[r.label]; const t0 = now(); const p = decide(r.claim, e, facts).set; ts.push(now() - t0); conf[y + '>' + p] = (conf[y + '>' + p] || 0) + 1; if (p === y) ok++; else bad.push(`${y}->${p}  ${r.claim}`); }
const n = c => rows.filter(r => LAB[r.label] === c).length, hit = (y, p) => conf[y + '>' + p] || 0;
const nonT = rows.length - n('T'), fa = hit('F', 'T') + hit('U', 'T');
const res = { n: rows.length, pool: pool.length, accuracy: ok / rows.length, per_label_recall: { T: hit('T', 'T') / n('T'), F: hit('F', 'F') / n('F'), U: hit('U', 'U') / n('U') }, false_admit_rate: fa / nonT, false_admits: fa, confusion: conf, p50_ms: ts.sort((a, b) => a - b)[Math.floor(ts.length / 2)] };
console.log(JSON.stringify(res)); console.log(bad.join('\n')); fs.writeFileSync(process.argv[3] || 'results_en_fever_style.json', JSON.stringify({ ...res, errors: bad }, null, 1));
